<?php
require_once dirname(__FILE__) . '/../src/musicbrowser.php';
require_once 'PHPUnit/Framework.php';

class MusicBrowserTest extends PHPUnit_Framework_TestCase {

  //private $mb;

  protected function setUp() {
  //      $this->mb = new MusicBrowser();
  }

  public function testResolve_config() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testDisablePlayMethod() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_fatal_error() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_page() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_content() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_searchfield() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_admin() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_search() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_streamtype() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_builddb() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_flashplayer() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testJson_encode() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_folder() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_options() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testItems_by_initial() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testGroup_items() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testList_folder() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testResolve_streamtype_and_shuffle() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_cover() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_linkedtitle() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHtml_breadcrumb() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testValid_suffix() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testFolder_items() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testStream() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testEntry_info() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testInvoke_xbmc() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testPlay_xbmc() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testPlay_server() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testPlay_slimserver() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testShow_messages() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testHttp_get() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testSearch() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testDecode_ncd() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }

  public function testBuild_searchdb() {
    $this->markTestIncomplete('This test has not been implemented yet.');
  }
}
?>
