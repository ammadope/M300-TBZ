Installation
------------
Place the file templates/henrie/template.inc in the same folder as template.inc.
Then the only thing you will have to do is change a setting in index.php:
Change 'columns' => 5 to 'columns' => 1;

Notes
-----
I use it for playing music (300+ albums) from my NAS (Synology DS107+).
I did not like the standard layout template to much, so after using it
for about a year i finally made my own template.

The template is not flexible enough for small screens (maybe i will
enhance it in the future) so for now it is adviced to use a screen of at
least 1000px wide and 550px high (when you want to use the default
flashplayer height of 150px).

Enjoy.

Greetings,
Henrie

Credits
-------
This is a template for Music Browser by Henrie van der Locht

More info: 
- http://drop.io/musicbrowser/
- http://sourceforge.net/forum/message.php?msg_id=7341233
