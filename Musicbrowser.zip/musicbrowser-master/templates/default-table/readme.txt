Installation
------------
Replace the regular template.inc with this one.

Notes
-----
This is the old table based template
